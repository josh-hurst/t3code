#pragma once

#import <UIKit/UIKit.h>

#if defined(__cplusplus)
#import <React/RCTComponent.h>
#import <React/RCTViewComponentView.h>
#import <React/RCTViewManager.h>
#import <react/renderer/components/rnscreens/RCTComponentViewHelpers.h>
#endif

#import "RNSDefines.h"
#import "RNSLegacyEnums.h"

@class RNSSearchBar;

@protocol RNSSearchBarNavigationItemDelegate <NSObject>

- (void)searchBarDidUpdateNavigationItem:(RNSSearchBar *)searchBar;

@end

@interface RNSSearchBar :
#if defined(__cplusplus)
    RCTViewComponentView <UISearchBarDelegate, UISearchControllerDelegate, RCTRNSSearchBarViewProtocol>
#else
    UIView <UISearchBarDelegate, UISearchControllerDelegate>
#endif

@property (nonatomic, weak, nullable) id<RNSSearchBarNavigationItemDelegate> navigationItemDelegate;

@property (nonatomic) BOOL hideWhenScrolling;
@property (nonatomic) BOOL cancelButtonHidden;
@property (nonatomic) RNSSearchBarPlacement placement;
@property (nonatomic) BOOL allowToolbarIntegration;

@property (nonatomic, retain) UISearchController *controller;

/// Deactivates a search controller for a reason other than the user closing search, such as its
/// screen disappearing, so its search bar does not report the dismissal as a cancel.
+ (void)deactivateSearchController:(UISearchController *)searchController;

#if RNS_IPHONE_OS_VERSION_AVAILABLE(16_0) && !TARGET_OS_TV
- (UINavigationItemSearchBarPlacement)placementAsUINavigationItemSearchBarPlacement API_AVAILABLE(ios(16.0))
    API_UNAVAILABLE(tvos, watchos);
#endif // Check for iOS >= 16 && !TARGET_OS_TV

@end

#if defined(__cplusplus)
@interface RNSSearchBarManager : RCTViewManager
#else
@interface RNSSearchBarManager : NSObject
#endif

@end
